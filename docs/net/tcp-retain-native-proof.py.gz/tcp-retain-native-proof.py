import gzip,hashlib,json,re,subprocess
from pathlib import Path
root=Path.cwd();folder=root/'.sn/tcp-goal';base='6e796dd36fdaea7d99a7407b19949456fb7e37d4';compiler=Path('/home/gavin/code/sindarin/sindarin-rust-method-struct-qualifiers/bin/sn');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
normal=json.loads((root/'.sn/tcp-native.json').read_text());san=json.loads((root/'.sn/tcp-sanitizers.json').read_text())
assert normal['passed'] and len(normal['cases'])==21 and san['passed'] and len(san['cases'])==1
assert normal['compiler_sha256']==san['compiler_sha256']==sha(compiler)=='a99c00a6410811ae42dce4b0005feb8ca0cc4f61f35e9252d01f6269a2651dc3'
for v in (normal,san):
 assert v['script_sha256']==sha(root/'scripts/check_tcp_native.py')
 for rel,h in v['sources'].items():assert sha(root/rel)==h,rel
 for rel,h in v['client_sha256'].items():assert sha(root/'tests/native'/rel)==h,rel
 assert v['runtime_archive_sha256']==sha(compiler.parent/'lib/gcc/libsn_runtime_min.a')
 for rel,h in v['runtime_header_sha256'].items():assert sha(compiler.parent/'include/runtime'/rel)==h,rel
for rel,h in san['runtime_source_sha256'].items():assert sha(compiler.parent.parent/'src/runtime'/rel)==h,rel
assert len(san['runtime_source_sha256'])==4
assert normal['legacy_layout']['values']['legacy']==normal['legacy_layout']['values']['canonical'] and len(normal['legacy_layout']['values']['legacy'])==18
protected={}
for raw in subprocess.check_output(['git','ls-tree','-r','-z','--name-only',base]).split(b'\0'):
 if not raw:continue
 rel=raw.decode()
 if not rel.endswith(('.sn','.expected')):continue
 data=subprocess.check_output(['git','show',base+':'+rel]);assert (root/rel).read_bytes()==data,rel;protected[rel]=hashlib.sha256(data).hexdigest()
assert len(protected)==87
sweep=json.loads((folder/'original-C-default.json').read_text());assert sweep['passed'] and len(sweep['cases'])==28 and sweep['compiler_sha256']==sha(compiler) and sweep['all_sources_oracles_preserved'] and sweep['native_sources_unchanged']
for rel,h in sweep['native_source_sha256'].items():assert sha(root/rel)==h,rel
initial=json.loads((folder/'original-C.json').read_text());old=json.loads((folder/'original-C-baseline-debug.json').read_text());current=json.loads((folder/'original-C-current-baseline-debug.json').read_text());assert len(initial['cases'])==28 and sum(c['passed'] for c in initial['cases'])==23 and len(old['cases'])==5 and not any(c['passed'] for c in old['cases']) and len(current['cases'])==5 and sum(c['passed'] for c in current['cases'])==1
assert [c['source'] for c in current['cases'] if c['passed']]==['tests/encoding/test_zlib.sn']
assert initial['script_sha256']==sha(folder/'check-original-C-initial.py')
assert old['script_sha256']==sha(folder/'check-original-C-modes.py')
assert current['script_sha256']==sha(folder/'check-original-C-compiler-selection.py')
api=json.loads((folder/'public-api-model.json').read_text());assert len(api['functions'])==10 and len(api['structs'])==2 and sum(len(v['methods']) for v in api['structs'])==15
public_targets={v.get('c_alias') or v['name'] for v in api['functions']}
public_targets.update(m['c_alias'] for v in api['structs'] for m in v['methods'] if m.get('is_native') and m.get('c_alias'))
header_targets=set(re.findall(r'\b(sn_tcp_[a-z_]+)\s*\(', (root/'src/net/tcp.native.h').read_text()));assert public_targets==header_targets and len(header_targets)==15
leaks=[]
for c in current['cases']:
 if c['passed']:continue
 text=bytes.fromhex(c['run']['stderr_hex']).decode(errors='replace');summary=re.findall(r'SUMMARY: AddressSanitizer: (.*)',text);assert summary
 leaks.append({'source':c['source'],'summary':summary,'status':'Open legacy C debug lifetime failure; no parity credit'})
assert 'Ran 11 tests' in (folder/'native-oracle-contract.log').read_text()
paths={'native.json':root/'.sn/tcp-native.json','sanitizers.json':root/'.sn/tcp-sanitizers.json'}
for name in ('final-native-normal.log','final-native-sanitized.log','check-original-C.py','check-original-C-initial.py','check-original-C-modes.py','check-original-C-compiler-selection.py','original-C.json','original-C.log','original-C-default.json','final-original-C-default.log','original-C-baseline-debug.json','original-C-baseline-debug.log','original-C-current-baseline-debug.json','original-C-current-baseline-debug.log','runtime-before-disconnect.json','runtime-after-disconnect.log','native-oracle-contract.log','public-api-model.json','native-client-before-shutdown-expansion.c','retain-native-proof.py'):paths[name]=folder/name
retained=[]
for name,p in paths.items():
 out=root/'docs/net'/('tcp-'+name+'.gz');out.write_bytes(gzip.compress(p.read_bytes(),mtime=0));retained.append({'path':str(out.relative_to(root)),'sha256':sha(out),'raw_sha256':sha(p)})
proof={'status':'Complete native C foundation local validation; hosted SDK acceptance and compiler artifact wiring remain required.','base_revision':base,'compiler_revision':'5b51af8c769dd6c1bf28fb7b0e97d25b3cdb3596','compiler_sha256':sha(compiler),'normal_native_layout_and_unchanged_legacy_cases':21,'actual_C_runtime_sanitizer_cases':1,'full_original_SDK_C_default_cases':28,'CI_helper_tests':11,'public_records':2,'public_functions':10,'public_methods':15,'raw_C_backing_entrypoints':15,'independent_layout_values':normal['legacy_layout']['values'],'source_preservation':{'all_tracked_Sindarin_and_expected_files_unchanged':True,'file_count':87,'sha256':protected},'source_and_client_sha256':{str(p.relative_to(root)):sha(p) for p in [root/'src/net/tcp.sn.c',root/'src/net/tcp.native.c',root/'src/net/tcp.native.h',root/'tests/native/tcp.c',root/'tests/native/tcp.rs',root/'scripts/check_tcp_native.py',root/'.github/workflows/ci.yml']},'implementation':'One C TCP implementation shared by standalone archives and legacy imports. Canonical records retain visible layouts and fields; private allocation prefixes distinguish factory-owned resources from zero/default records. Atomic credits close factory resources on last release, preserve aliases and permit idempotent explicit disposal. WinSock initialization is serialized. Peer disconnects use per-send/per-socket SIGPIPE prevention, without changing process signal disposition.','independent_controls':'C/Rust archive clients cover all15 raw entrypoints, live aliases, owned snapshots after owner release, binary/NUL/high bytes, line/buffer reads, EOF, timeouts, disposal, zero/default/nil states, stdin preservation, repeated loopback and parallel independent factories. The checker includes platform socket/descriptor closure checks, a portable readable-socket shutdown test and a POSIX default-SIGPIPE child test. Generated legacy C is independently compared with canonical storage for sizes, alignments and all field offsets/widths.','legacy_debug_findings':{'accepted_5b_full_C_debug_passed':23,'accepted_5b_full_C_debug_total':28,'same_five_fail_on_unchanged_SDK_baseline':True,'current_correction_compiler':'61633bb80d15bc0df80b4aee2d86ac2bbe75082e','current_Zlib_debug_passes':True,'open_C_lifetime_failures':leaks,'scope':'Debug enables the compiler default ASAN/UBSAN. Failed modes are retained and never counted as parity. These failures are separate from successful normal C28 and canonical TCP C/runtime SAN1. Older Zlib74 is repaired by the pending compiler correction.'},'retained_reports':retained,'scope':'No existing Sindarin source or behavioral oracle changed. Native foundation only; complete Linux/macOS/Windows SDK acceptance, compiler source/sealed TCP artifact adapters and broader Rust/C ownership/language/lifecycle parity remain open.'}
(root/'docs/net/tcp-native-validation.json').write_text(json.dumps(proof,indent=2)+'\n');print('Verified native21 / actual runtime SAN1 / default C28 / original87 hashes; retained',len(retained),'reports and four open legacy C leaks.')
