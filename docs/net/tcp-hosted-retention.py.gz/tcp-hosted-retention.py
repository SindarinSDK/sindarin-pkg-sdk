import gzip,hashlib,json
from pathlib import Path
root=Path.cwd();folder=root/'.sn/tcp-goal/hosted-40222092078';sha=lambda data:hashlib.sha256(data).hexdigest();r=json.loads((folder/'final.json').read_text());assert r['conclusion']=='success' and r['headSha']=='9d2e6e792746ce22d4ee3e744bc3f9938b59b104' and len(r['jobs'])==7 and all(j['conclusion']=='success' for j in r['jobs'])
compilers={};retained=[];checkout={};layouts={}
def keep(name,p):
 out=root/'docs/net'/('tcp-hosted-'+name+'.gz');out.write_bytes(gzip.compress(p.read_bytes(),mtime=0));retained.append({'path':str(out.relative_to(root)),'sha256':sha(out.read_bytes()),'raw_sha256':sha(p.read_bytes())})
def matches(path,expected,platform):
 data=path.read_bytes();candidates={'LF':sha(data)}
 if platform=='Windows':candidates['CRLF checkout']=sha(data.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n'))
 assert expected in candidates.values(),(path,expected,candidates)
 return next(n for n,h in candidates.items() if h==expected)
for runner,platform in [('ubuntu-latest','Linux'),('macos-latest','Darwin'),('windows-latest','Windows')]:
 p=next((folder/runner).rglob('tcp-native.json'));v=json.loads(p.read_text());assert v['passed'] and len(v['cases'])==21 and all(c['passed'] for c in v['cases']) and v['platform']==platform;compilers[platform]=v['compiler_sha256'];modes=set()
 modes.add(matches(root/'scripts/check_tcp_native.py',v['script_sha256'],platform))
 for rel,h in v['sources'].items():modes.add(matches(root/rel.replace('\\','/'),h,platform))
 for rel,h in v['client_sha256'].items():modes.add(matches(root/'tests/native'/rel,h,platform))
 assert v['legacy_layout']['values']['legacy']==v['legacy_layout']['values']['canonical'] and len(v['legacy_layout']['values']['legacy'])==18;layouts[platform]=v['legacy_layout']['values'];checkout[platform]=sorted(modes)
 assert matches(root/'src/net/tcp.sn',v['legacy_layout']['source_sha256'],platform)
 for name in ('udp-native.json','yaml-native.json'):
  other=json.loads(next((folder/runner).rglob(name)).read_text());assert other['passed'] and other['compiler_sha256']==v['compiler_sha256']
 keep(runner+'-tcp-native.json',p)
p=next((folder/'ubuntu-latest').rglob('tcp-sanitizers.json'));v=json.loads(p.read_text());assert v['passed'] and len(v['cases'])==1 and v['compiler_sha256']==compilers['Linux'] and len(v['runtime_source_sha256'])==4;keep('linux-tcp-sanitizers.json',p)
keep('final.json',folder/'final.json');keep('artifacts.json',folder/'artifacts.json');keep('retention.py',root/'.sn/tcp-goal/retain-hosted-proof.py')
proof={'status':'Complete own-revision SDK Linux/macOS/Windows hosted acceptance verified. Native TCP foundation accepted; compiler source/sealed TCP artifact integration remains required.','revision':r['headSha'],'CI':40222092078,'url':r['url'],'required_jobs':7,'all_jobs_successful':True,'compiler_source_revision':'5b51af8c769dd6c1bf28fb7b0e97d25b3cdb3596','compilers':compilers,'native_and_original_TCP_cases_each_platform':21,'actual_C_module_and_runtime_sanitizer_cases_Linux':1,'layout_values':layouts,'source_checkout_evidence':checkout,'public_source_and_oracle_files_unchanged':87,'scope':'C/Rust archive and unchanged original caller behavior, ABI/layout preservation, reference ownership, snapshots, portable shutdown and socket closure on all three platforms; real POSIX disconnect/SIGPIPE behavior on Linux/macOS; C/runtime instrumentation on Linux. Existing primary SDK tests and other native helper jobs also passed. Four separately retained legacy C debug lifetime failures remain open and receive no parity credit. Full Rust/C parity is not complete.','retained_reports':retained}
(root/'docs/net/tcp-hosted-acceptance.json').write_text(json.dumps(proof,indent=2)+'\n');print('Verified SDK7/7, native21x3, actualC/runtimeSAN1, source/client hashes and identical18-value source layouts')
