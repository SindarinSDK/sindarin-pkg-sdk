import gzip,hashlib,json,subprocess
from pathlib import Path
root=Path.cwd();folder=root/'.sn/tls-goal';dest=root/'docs/net';dest.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
normal=read(root/'.sn/tls-native.json');san=read(root/'.sn/tls-sanitizers.json');legacy=read(folder/'legacy-SDK-before-after.json')
script=sha(root/'scripts/check_tls_native.py')
for d,count in [(normal,21),(san,1)]:
 assert d['passed'] and len(d['cases'])==count and d['script_sha256']==script
 assert d['compiler_sha256']=='d8a5e3a83c7d605ad23aec2177557098078046b9026cd41c5be4ebc94ac14329'
 for name,digest in d['client_sha256'].items():assert sha(root/'tests/native'/name)==digest
 for name,digest in d['sources'].items():assert sha(root/name)==digest
assert 'Ran 11 tests' in (folder/'native-oracles.log').read_text() and '\nOK\n' in (folder/'native-oracles.log').read_text()
assert len(normal['fatal_error_contracts'])==8
assert normal['legacy_layout']['values']['legacy']==normal['legacy_layout']['values']['canonical']
assert len(legacy['cases'])==112 and legacy['counts']=={'before':{'normal':28,'debug':24},'after':{'normal':28,'debug':24}}
failures=[{'revision':c['revision'],'source':c['source'],'leak':c['leak']} for c in legacy['cases'] if not c['passed']]
assert len(failures)==8 and {c['source'] for c in failures}=={'tests/core/test_random.sn','tests/encoding/test_yaml.sn','tests/net/test_git.sn','tests/net/test_ssh_server.sn'}
preservation=read(dest/'udp-native-validation.json')['source_preservation'];assert len(preservation['sha256'])==87
for name,digest in preservation['sha256'].items():assert sha(root/name)==digest
assert legacy['source_hashes']==preservation['sha256']
changed=subprocess.check_output(['git','diff','--name-only','9d2e6e79'],text=True).splitlines();assert not any(n.endswith(('.sn','.expected')) for n in changed)
reports=[]
for p in [root/'.sn/tls-native.json',root/'.sn/tls-sanitizers.json']+[folder/n for n in ['checker-full.log','checker-sanitized.log','legacy-SDK-before-after.json','legacy-SDK-before-after.log','check-legacy-sdk.py','retain-local.py','original-before-after.json','original-C-R-debug.json','parallel-descriptor-reuse-before.log','native-oracles.log']]:
 out=dest/('tls-local-'+p.name+'.gz');out.write_bytes(gzip.compress(p.read_bytes(),mtime=0));reports.append({'path':str(out.relative_to(root)),'sha256':sha(out),'raw_sha256':sha(p)})
paths=['src/net/tls.sn.c','src/net/tls.native.c','src/net/tls.native.h','scripts/check_tls_native.py','tests/native/tls.c','tests/native/tls.rs','tests/native/tls_certificate.c','tests/native/tls_errors.c','.github/workflows/ci.yml']
proof={'status':'Complete native TLS foundation local validation only. Feature publication is frozen pending the compiler path correction; no hosted TLS SDK or compiler artifact acceptance.',
 'base_revision':'9d2e6e792746ce22d4ee3e744bc3f9938b59b104','compiler_revision':'61633bb80d15bc0df80b4aee2d86ac2bbe75082e','compiler_sha256':normal['compiler_sha256'],
 'normal_native_layout_and_unchanged_legacy_cases':21,'separate_fatal_error_contracts':8,'actual_C_runtime_sanitizer_cases':1,'native_oracle_helper_tests':11,'original_external_TLS_modes':18,
 'original_full_SDK_C_default_before_after':[28,28],'original_full_SDK_C_debug_before_after':[24,24],'public_records':2,'public_functions':10,'public_methods':14,'raw_C_backing_entrypoints':14,
 'independent_layout_values':normal['legacy_layout']['values'],'source_preservation':preservation,'source_and_client_sha256':{n:sha(root/n) for n in paths},
 'implementation':['Existing TLS C/OpenSSL implementation reused with matching public record layouts and private allocation prefixes. Last release disposes factory resources; default records preserve stdin; stream string fields are freed once.','Registry limits remain 1024 streams / 256 listeners. Registry access and once initialization are serialized. Existing TLS process SIGPIPE policy is preserved.','No value copy hook is invented; legacy native TLS value copies lack a hook too.'],
 'independent_controls':['C archive and Rust FFI clients cover binary NUL/high bytes, UTF8 lines, snapshots, alias credits, concurrent factories, default/nil records, fd closure, portable shutdown wakeup and accepted stream lifetime after listener release.','Ephemeral localhost-only certificates are generated with linked OpenSSL. Trusted loopback succeeds; untrusted certificate and hostname mismatch reject through the same C error contract. System trust is unchanged.','Original external test source, example.com endpoint, certificate verification and oracle stay unchanged across nine C/Rust modes.'],
 'legacy_debug_findings':failures,'legacy_debug_note':'Four historical actual legacy C leaks persist. SSH leaked payload bytes vary while 27 allocations remain. Fresh external TLS passes do not explain or close the earlier unexplained TLS failure.',
 'retained_reports':reports,'remaining':['Own SDK Linux/macOS/Windows acceptance after compiler freeze lifts.','Compiler TLS artifact builds, bindings, source/sealed adapters and lifecycle matrices.','Remaining SDK modules and broader language/ownership/mixed-package/final platform goal work.']}
(dest/'tls-native-validation.json').write_text(json.dumps(proof,indent=2)+'\n');print('Retained TLS local foundation:',len(reports),'reports; all87 source/oracle hashes preserved')
