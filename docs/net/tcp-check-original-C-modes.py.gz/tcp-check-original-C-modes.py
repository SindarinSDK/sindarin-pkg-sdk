import argparse,hashlib,json,os,shutil,subprocess,tempfile,time
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--debug',action='store_true');parser.add_argument('--baseline',action='store_true');args=parser.parse_args()
root=Path.cwd();sdk=Path('/home/gavin/code/sindarin/sindarin-sdk-udp-canonical') if args.baseline else root
compiler=Path('/home/gavin/code/sindarin/sindarin-rust-method-struct-qualifiers/bin/sn');folder=root/'.sn/tcp-goal';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
protected=json.loads((root/'docs/net/udp-native-validation.json').read_text())['source_preservation']['sha256']
assert len(protected)==87 and all(sha(root/n)==h for n,h in protected.items())
sources=sorted(p for p in (sdk/'tests').rglob('*.sn') if p.with_suffix('.expected').is_file());assert len(sources)==28
if args.baseline:sources=[p for p in sources if p.stem in ('test_random','test_yaml','test_zlib','test_git','test_ssh_server')]
label=('baseline-' if args.baseline else '')+('debug' if args.debug else 'default')
report={'compiler_sha256':sha(compiler),'compiler_revision':'5b51af8c769dd6c1bf28fb7b0e97d25b3cdb3596','started':time.time(),'cases':[],'source_preservation':protected,'debug':args.debug,'baseline':args.baseline,'script_sha256':sha(Path(__file__)),'environment':{n:os.environ.get(n) for n in ('SN_CC','SN_CFLAGS','SN_RUSTFLAGS','ASAN_OPTIONS','UBSAN_OPTIONS')},'scope':'All28 original unchanged SDK C fixtures, or five selected debug-baseline failures, at O0 in an isolated copied SDK. Debug enables compiler-default sanitizers; non-debug is a separate behavior check. Raw failures remain uncredited.'}
def invoke(cmd,cwd,timeout,build=False):
 try:
  p=subprocess.run([str(x) for x in cmd],cwd=cwd,input=b'',capture_output=True,timeout=timeout)
  return {'status':p.returncode,'stdout_hex':p.stdout.hex(),'stderr_hex':p.stderr.hex()}
 except subprocess.TimeoutExpired as e:return {'status':'timeout','stdout_hex':(e.stdout or b'').hex(),'stderr_hex':(e.stderr or b'').hex()}
with tempfile.TemporaryDirectory(prefix='sn-sdk-tcp-original-C-') as temp:
 app=Path(temp);shutil.copytree(sdk/'src',app/'src');shutil.copytree(sdk/'tests',app/'tests');shutil.copyfile(sdk/'sn.yaml',app/'sn.yaml');(app/'.sn').mkdir();(app/'.sn/sindarin-pkg-sdk').symlink_to(app,target_is_directory=True)
 libs=compiler.parent.parent/'.sn/sindarin-pkg-libs'
 if libs.is_dir():(app/'.sn/sindarin-pkg-libs').symlink_to(libs.resolve(),target_is_directory=True)
 for source in sources:
  relative=source.relative_to(sdk);staged=app/relative;assert staged.read_bytes()==source.read_bytes();exe=app/'fixture.exe';cmd=[compiler,staged,'--no-install','--target','c','-O0','-o',exe]+(['-g'] if args.debug else [])
  case={'source':str(relative),'source_sha256':sha(source),'oracle_sha256':sha(source.with_suffix('.expected')),'command':list(map(str,cmd)),'compile':invoke(cmd,app,180,True)}
  if case['compile']['status']==0:
   case['run']=invoke([exe],app,60);expected=source.with_suffix('.expected').read_bytes().replace(b'\r\n',b'\n');expected_error=b'OK\n'*4 if source.name=='test_stdio.sn' else b''
   case['output_matches']=bytes.fromhex(case['run']['stdout_hex']).replace(b'\r\n',b'\n')==expected;case['stderr_matches']=bytes.fromhex(case['run']['stderr_hex']).replace(b'\r\n',b'\n')==expected_error
  case['passed']=case['compile']['status']==0 and case['run']['status']==0 and case['output_matches'] and case['stderr_matches'];report['cases'].append(case)
  (folder/('original-C-'+label+'.partial.json')).write_text(json.dumps(report,indent=2)+'\n');print(relative,'PASS' if case['passed'] else 'FAIL',case['compile']['status'],case.get('run',{}).get('status'),flush=True)
report['finished']=time.time();report['passed']=all(c['passed'] for c in report['cases']);report['all_sources_oracles_preserved']=all(sha(root/n)==h for n,h in protected.items());report['compiler_unchanged']=sha(compiler)==report['compiler_sha256'];assert report['all_sources_oracles_preserved'] and report['compiler_unchanged'];(folder/('original-C-'+label+'.json')).write_text(json.dumps(report,indent=2)+'\n');print('Original SDK C:',sum(c['passed'] for c in report['cases']),'/',len(sources),flush=True)
raise SystemExit(0 if report['passed'] else 1)
