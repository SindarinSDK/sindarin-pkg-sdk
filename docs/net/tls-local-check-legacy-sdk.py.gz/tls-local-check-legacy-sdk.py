import hashlib,json,os,re,shutil,subprocess,time
from pathlib import Path
root=Path.cwd();folder=root/'.sn/tls-goal';compiler=root.parent/'sindarin-sdk-zlib-artifacts/bin/sn';baseline=root.parent/'sindarin-sdk-tcp-accepted'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
fixtures=sorted(root.glob('tests/**/*.sn'));fixtures=[p for p in fixtures if p.with_suffix('.expected').exists()];assert len(fixtures)==28
report={'status':'running','compiler_sha256':sha(compiler),'baseline_revision':'9d2e6e792746ce22d4ee3e744bc3f9938b59b104','cases':[],'source_hashes':{str(p.relative_to(root)):sha(p) for p in sorted(list((root/'src').rglob('*.sn'))+list((root/'tests').rglob('*.sn'))+list((root/'tests').rglob('*.expected')))},'scope':'Actual legacy SDK C source, before/after TLS native backing changes, unchanged 28 original tests and oracles. Existing debug leaks and historical unexplained external TLS failure remain open.'}
out=folder/'legacy-SDK-before-after.json'
def save():out.write_text(json.dumps(report,indent=2)+'\n')
save()
for label,source in [('before',baseline),('after',root)]:
 work=folder/('compatibility-'+label);work.mkdir(exist_ok=True)
 for name in ['src','tests']:
  shutil.copytree(source/name,work/name,dirs_exist_ok=True)
 shutil.copyfile(source/'sn.yaml',work/'sn.yaml');(work/'.sn').mkdir(exist_ok=True)
 link=work/'.sn/sindarin-pkg-sdk'
 if not link.exists():link.symlink_to(work,target_is_directory=True)
 (work/'tmp').mkdir(exist_ok=True)
 env=dict(os.environ,TMPDIR=str(work/'tmp'),ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1')
 for mode in ['normal','debug']:
  for original in fixtures:
   path=original.relative_to(root);source=work/path;assert source.read_bytes()==original.read_bytes()
   expected=original.with_suffix('.expected').read_bytes().replace(b'\r\n',b'\n')
   exe=work/'case.exe';command=[str(compiler),str(source),'--no-install','--target','c','-O0','-o',str(exe)]+(['-g'] if mode=='debug' else [])
   item={'revision':label,'source':str(path),'mode':mode,'command':command};start=time.time()
   try:
    build=subprocess.run(command,cwd=work,env=env,capture_output=True,timeout=180)
    item.update(compile_status=build.returncode,compile_stdout_hex=build.stdout.hex(),compile_stderr_hex=build.stderr.hex())
    if not build.returncode:
     run=subprocess.run([str(exe)],cwd=work,env=env,capture_output=True,timeout=90)
     item.update(run_status=run.returncode,stdout_hex=run.stdout.hex(),stderr_hex=run.stderr.hex(),oracle_matches=run.stdout==expected)
     match=re.search(rb'SUMMARY: AddressSanitizer: (\d+) byte\(s\) leaked in (\d+) allocation',run.stderr)
     if match:item['leak']={'bytes':int(match[1]),'allocations':int(match[2])}
     expected_error=b'OK\n'*4 if path.as_posix()=='tests/io/test_stdio.sn' else b''
     item['expected_stderr_hex']=expected_error.hex()
     item['passed']=run.returncode==0 and run.stdout==expected and run.stderr==expected_error
   except subprocess.TimeoutExpired as error:
    item.update(timeout=True,error=str(error),stdout_hex=(error.stdout or b'').hex(),stderr_hex=(error.stderr or b'').hex(),passed=False)
   item['elapsed_seconds']=time.time()-start;report['cases'].append(item);save();print(label,mode,path,item.get('passed'),item.get('leak',''),flush=True)
for path,digest in report['source_hashes'].items():assert sha(root/path)==digest
report['status']='complete';report['sources_and_oracles_preserved']=True
report['counts']={label:{mode:sum(c.get('passed',False) for c in report['cases'] if c['revision']==label and c['mode']==mode) for mode in ['normal','debug']} for label in ['before','after']};save();print(report['counts'],flush=True)
